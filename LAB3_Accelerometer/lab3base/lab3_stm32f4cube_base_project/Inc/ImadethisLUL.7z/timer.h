/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __adc_H
#define __adc_H
#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
	 
/* Prototypes ----------------------------------------------------------------*/
void initTimer();
	 

#ifdef __cplusplus
}
#endif
#endif /*__ adc_H */